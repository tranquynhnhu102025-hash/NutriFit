package com.example.nutrifit; // Kiểm tra xem đúng package của bạn không nha

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btnThemBuaAn, btnUongNuoc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Ánh xạ các nút bấm trong Card Calo
        btnThemBuaAn = findViewById(R.id.btnThemBuaAn);
        btnUongNuoc = findViewById(R.id.btnUongNuoc);

        // 2. Bắt sự kiện click nút "Thêm bữa ăn"
        btnThemBuaAn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Chức năng Thêm bữa ăn đang phát triển!", Toast.LENGTH_SHORT).show();
            }
        });

        // 3. Bắt sự kiện click nút "Uống nước"
        btnUongNuoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Đã ghi nhận uống nước thành công!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}